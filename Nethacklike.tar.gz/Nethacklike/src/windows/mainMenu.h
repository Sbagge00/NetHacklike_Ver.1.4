#ifndef MAIN_MENU_H
#define MAIN_MENU_H

enum {START_GAME, END_GAME};

int mainMenu(int numberItems, char * choices[]);

#endif
