#include "rogue.h"

//clears the screen by printing spaces

int screenGameOver(Player * user)
{
  printw("YOU DIED. Press 'Q' to exit.                      ");
  mvprintw(5, 11,  "   _||_  ");
  mvprintw(6, 11,  "    ||   ");
  mvprintw(7, 11,  " ===||===");
  mvprintw(8, 11,  "|        |");
  mvprintw(9, 11,  "|  REST  |");
  mvprintw(10, 11, "|  IN    |");
  mvprintw(11, 11, "|  PEACE |");
  mvprintw(12, 11, "|        |");
  mvprintw(13, 11, "|Level: %d|", user->level);
  mvprintw(14, 11, "|        |");
  mvprintw(15, 10, "vvvvvvvvvvvv", user->class);


}

int chooseRaceScreen()
{
  clear();  
initscr();

    keypad(stdscr, TRUE);
  mvprintw(2, 1, "Choose your character race.");
  mvprintw(3, 3, "o - Orc:        +2 Strength, +2 Constitution, -1 INT. Extra attack damage.");
  mvprintw(4, 3, "d - Dragonborn: +2 Strength, +1 Charisma. Breath attack.");
  mvprintw(5, 3, "f - Dwarf:      +2 Strength, +1 Wisdom. Extra health per level."); // coded
  mvprintw(6, 3, "e - Elf:        +2 Dexterity, +1 Intelligence. Sleep and charm resistance.");
  mvprintw(7, 3, "g - Gith:       +1 Strength, +1 Intelligence, +1 Wisdom. Psionic sight.");
  mvprintw(8, 3, "h - Hobbit:     +2 Dexterity, +1 Charisma. Nimble."); // coded
  mvprintw(9, 3, "H - Human:      +1 to Strength, Dexterity, Constitution, Intelligence, Wisdom, Charisma."); // coded

  getch();

  clear();
  mvprintw(0, 0, "");

  noecho();
  refresh();

  return 0;
}

int chooseClassScreen()
{
  clear();  
initscr();

    keypad(stdscr, TRUE);
  mvprintw(2, 1, "Choose your character class.");
  mvprintw(3, 3, "B - Barbarian; Fierce warrior who uses Strength. Unarmored defence."); // coded
  mvprintw(4, 3, "C - Cleric: Priest that uses Wisdom to cast miracles."); // coded
  mvprintw(5, 3, "F - Fighter: Skilled combatant who use Strength and Dexterity.");
  mvprintw(6, 3, "P - Paladin: Holy knight bound to an oath. Uses Charisma to cast spells."); // coded
  mvprintw(7, 3, "R - Rogue: Scoundrel and theif who uses Dexterity."); // coded
  mvprintw(8, 3, "S - Sorcerer: Innately magical spellcaster that uses Charisma."); // coded
  mvprintw(9, 3, "w - Wizard: Studied spellcaster who uses Intelligence."); // coded

  getch();

  clear();
  mvprintw(0, 0, "");

  noecho();
  refresh();

  return 0;
}

int screenSetUp()
{
  initscr();

    keypad(stdscr, TRUE);

  mvprintw(2, 6, "Time is running out. The cult of the unseen eye has power unstoppable.");
  mvprintw(3, 6, "Power to awaken the ancient one from their slumber. The last day has fallen and");
  mvprintw(4, 6, "darkness covers the land. People cry out for a savior.");

  start_color();
  init_pair(1,COLOR_CYAN, COLOR_BLACK);
  attron(COLOR_PAIR(1));
    mvprintw(6, 6, "                                                                   ORION, the Master Sword");
  attroff(COLOR_PAIR(1));

  mvprintw(6, 6, "Legend speaks of a magical artifact lost to the annals of history.");

  mvprintw(7, 6, "A group of mighty warriors unite to find this artifact and stop the cult from achieving");
  mvprintw(8, 6, "their goal.");

  mvprintw(10, 6, "You have been tasked by this group to investigate a dungeon rumored to hold this mighty");
  mvprintw(11, 6, "weapon.");

  mvprintw(13, 6, "The clouds above you reveal a blue moon as you make your way to the dungeon entrance. ");
  mvprintw(14, 6, "The howls of lost souls fill the night as you find a graveyard and stone chapel.");

  mvprintw(16, 6, "Your time has come, adventurer! Now go forth with the hope of all people!");


  getch();

  clear();
  mvprintw(0, 0, "");

  noecho();
  refresh();

  return 0;
}

/* int printGameHub(Level * level)
{

  mvprintw(30, 29, "STR: %d", level->user->strength);
  mvprintw(30, 36, "(%d)", level->user->strMod);
  mvprintw(30, 41, "DEX: %d", level->user->dexterity);
  mvprintw(30, 48, "(%d)", level->user->dexMod);
  mvprintw(30, 53, "CON: %d", level->user->constitution);
  mvprintw(30, 60, "(%d)", level->user->conMod);
  mvprintw(30, 65, "INT: %d", level->user->intelligence);
  mvprintw(30, 72, "(%d)", level->user->intMod);
  mvprintw(30, 77, "WIS: %d", level->user->wisdom);
  mvprintw(30, 84, "(%d)", level->user->wisMod);
  mvprintw(30, 89, "CHA: %d", level->user->charisma);
  mvprintw(30, 96, "(%d)", level->user->chaMod);

  mvprintw(31, 1, "HP: %d", level->user->hp);
  mvprintw(31, 7, "(%d)", level->user->maxhp);
  mvprintw(31, 13, "Level: %d", level->user->level);
  mvprintw(31, 23, "AC: %d", level->user->ac);

	return 1;
} */ 
