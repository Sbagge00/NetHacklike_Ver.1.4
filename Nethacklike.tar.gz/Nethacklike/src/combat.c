#include "rogue.h"


int arrowTrap(Position * newPosition, Player * user, char ** level)
{
	int num;	
	srand(time(0));
  	num = rand() % 20 + user->dexMod;
	if (num >= 13)
	{    	
	mvprintw(0, 0, "You spring a spike trap! The spikes hit you!    ");	
	user->hp -= 1;
 	mvprintw(31, 1, "HP: %d(%d) ", user->hp, user->maxhp);
        health(newPosition, user, level);
	} else {
	mvprintw(0, 0, "You sprung a spike trap! But you dodge out of the way! ");
	}
	return 1;
}

int healing(Position * newPosition, Player * user, char ** level)
{
    	if (user->hp < user->maxhp)
	{
	user->hp += 1;
 	mvprintw(31, 1, "HP: %d(%d) ", user->hp, user->maxhp);
        health(newPosition, user, level);
	} else {
	mvprintw(31, 1, "HP: %d(%d) ", user->hp, user->maxhp);
	}

	return 1;
}

int spellHealingWork(Position * newPosition, Player * user, char ** level)
{
	int num;	
	srand(time(0));
  	num = rand() % 4 + user->wisMod;
    	if (user->hp < user->maxhp)
	{
	user->hp += num;
	if (user->hp > user->maxhp)
        {
	user->hp = user->maxhp;
 	mvprintw(31, 1, "HP: %d(%d) ", user->hp, user->maxhp);
        health(newPosition, user, level);
	} else {
 	mvprintw(31, 1, "HP: %d(%d) ", user->hp, user->maxhp);
        health(newPosition, user, level);
	}
	}
	return 1;
}

int pitTrap(Position * newPosition, Player * user, char ** level)
{
	mvprintw(0, 0, "You fall down a pit!");	
	user->hp -= 7;
 	mvprintw(31, 1, "HP: %d(%d) ", user->hp, user->maxhp);
        health(newPosition, user, level);
	return 1;
}
