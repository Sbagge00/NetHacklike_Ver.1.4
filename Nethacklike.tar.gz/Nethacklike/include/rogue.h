#ifndef ROGUE_H
#define ROGUE_H

#include <ncurses.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct Level
{
  struct Player * user;
} Level;

typedef struct Position {
  int x;
  int y;
  // TILE_TYPE tile;
} Position;

typedef struct Player
{
  Position position;
  int level;
  int hp;
  int maxhp;
  int b_strength;
  int b_dexterity;
  int b_constitution;
  int b_intelligence;
  int b_wisdom;
  int b_charisma;
  int strength;
  int dexterity;
  int constitution;
  int intelligence;
  int wisdom;
  int charisma;
  int strMod;
  int dexMod;
  int conMod;
  int intMod;
  int wisMod;
  int chaMod;
  int ac;
  int gold;
  int class;
  int race;
  int alignment;
  int armor;
  int armorBonus;
  int spellSlot;
  int acMagic;
} Player;

int screenSetUp();
int checkTrapsUp(Position * newPosition, Player * user, char ** level);
int checkTrapsDown(Position * newPosition, Player * user, char ** level);
int checkTrapsLeft(Position * newPosition, Player * user, char ** level);
int checkTrapsRight(Position * newPosition, Player * user, char ** level);
int secretDoorRight(Position * newPosition, Player * user, char ** level);
int secretDoorLeft(Position * newPosition, Player * user, char ** level);
int lvlTrap(Position * newPosition, Player * user, char ** level);
int lvlOne();
int lvlTwo();
//int printGameHub(Level * level);

char ** saveLevelPositions();

Player * playerSetUp();
Position * handleInput(int input, Player * user, char ** level);

Player * chooseRace(int input, Player * user, char ** level);
Player * selectCharacter(int input, Player * user, char ** level);

int checkPosition(Position * newPosition, Player * user, char ** level);
int playerMove(Position * newPosition, Player * user, char ** level);

int randAttack(void);

int health(Position * newPosition, Player * user, char ** level);
int startHealth(Player * user, char ** level);
int spells(Position * newPosition, Player * user, char ** level);

int arrowTrap(Position * newPosition, Player * user, char ** level);
int pitTrap(Position * newPosition, Player * user, char ** level);
int spellHealingWork(Position * newPosition, Player * user, char ** level);
int healing(Position * newPosition, Player * user, char ** level);

#endif
