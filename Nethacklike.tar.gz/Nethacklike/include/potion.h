#ifndef POTION_H
#define POTION_H



typedef struct Potion
{
    PotionType type;
    int effect;
}

#endif
